package kit.edu.pse.goapp.server.daos;

import kit.edu.pse.goapp.server.datamodels.GPS;

public interface GPS_DAO {
	
	public void userSetGPS();
	public GPS userGetGPS();

}
