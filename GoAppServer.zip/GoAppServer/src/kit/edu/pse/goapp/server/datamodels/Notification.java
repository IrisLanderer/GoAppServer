
package kit.edu.pse.goapp.server.datamodels;

public class Notification {

	private String text;
	public Notification(String text)
	{
		this.text = text;
	}
	public String getText()
	{
		return text;
	}
	
}
