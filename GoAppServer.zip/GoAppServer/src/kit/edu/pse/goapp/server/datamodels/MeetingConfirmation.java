package kit.edu.pse.goapp.server.datamodels;

public enum MeetingConfirmation {
	CONFIRMED, PENDING, REJECTED

}
